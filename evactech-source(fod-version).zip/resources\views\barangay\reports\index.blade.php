@extends('layouts.staff')

@section('title', 'Report Generation')
@section('page-title', 'Report Generation')
@section('page-subtitle', 'Generate downloadable reports for your barangay\'s evacuation center.')

{{--
    Converted to Tailwind (roadmap item 2).

    The barangay views take a NARROWER conversion than the public ones: layout,
    spacing and responsive behaviour move to utilities, but shared component
    classes (.card, .panel, .btn-*, .badge*, .field, .data-table, .kpi-*,
    .alert*, .empty-note, .modal*) stay as classes. Those are defined in
    staff.css and are still used verbatim by the City Admin and Super Admin
    views, which Chat C has not converted yet -- rewriting them here would mean
    either breaking those pages or converting them out of turn.

    Chat C should follow the same rule so the two halves match.
--}}

@section('content')
{{--
    PHASE 3 ITEM 11a -- the CSWDO IDP Monitoring Form.

    Its OWN panel and its OWN route, not another option in the dropdown below.
    That dropdown validates against ReportController::TYPES and offers a PDF/xlsx
    choice; this form is a fixed two-cross-tab layout that exists to be printed
    and signed, so an xlsx of it would be a broken artifact. Keeping it separate
    also means the five working report types are untouched.

    Scoped to the ACTIVE shelter for this account, resolved by
    ResolvesCenter. The city-wide "Accumulated Shelters" variant is City Admin's.
--}}
<section class="card panel mb-4">
    <h2 class="panel-title">CSWDO IDP Monitoring Form</h2>
    <p class="mb-3 text-sm text-ink-muted">
        The official CSWDO monitoring sheet for
        <strong>{{ $center?->name ?? 'this shelter' }}</strong>, filled in from the
        families checked in right now. Age groups and vulnerable categories are
        counted for you. PDF only, ready to print and sign.
    </p>

    <form method="POST" action="{{ route('barangay.reports.idp') }}">
        @csrf
        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div class="field">
                <label for="idp-disaster">Name of disaster</label>
                <input type="text" id="idp-disaster" name="disaster_name" maxlength="150"
                       placeholder="e.g. Typhoon Kristine"
                       value="{{ old('disaster_name') }}" required>
            </div>
            <div class="field">
                <label for="idp-date">Date of disaster</label>
                <input type="date" id="idp-date" name="disaster_date"
                       max="{{ now()->toDateString() }}"
                       value="{{ old('disaster_date') }}" required>
            </div>
        </div>

        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div class="field">
                <label for="idp-families">Number of affected families</label>
                <input type="number" id="idp-families" name="affected_families" min="0"
                       value="{{ old('affected_families', $idpCounts['families']) }}">
                <p class="mt-1 text-xs text-ink-muted">
                    Pre-filled with the {{ $idpCounts['families'] }} checked in here now.
                    The form asks for the city-wide figure, so overwrite this if CDRRMO
                    has given you one. Clear it to print a blank line instead.
                </p>
            </div>
            <div class="field">
                <label for="idp-persons">Number of affected persons</label>
                <input type="number" id="idp-persons" name="affected_persons" min="0"
                       value="{{ old('affected_persons', $idpCounts['persons']) }}">
                <p class="mt-1 text-xs text-ink-muted">
                    Pre-filled with the {{ $idpCounts['persons'] }} present here now.
                    Same rule as families.
                </p>
            </div>
        </div>

        <p class="mb-3 text-xs text-ink-muted">
            Prepared by and Noted by print as blank signature lines. Noted by carries
            the OIC CSWDO designation.
        </p>

        {{-- DROP D. Preview streams the same $pdf object the download returns,
             so the two cannot disagree. Generate stays btn-primary and stays
             LAST, so it remains the form's default submit -- pressing Enter in
             a text field still downloads rather than previews.

             formtarget="_blank" is on the PREVIEW button only, not on the
             <form>. One attribute, no JS, no bundle rebuild, and the two
             buttons keep different targets from the same form: preview opens a
             new tab, Generate posts in place so the download and any
             validation errors land on the page the operator is looking at. --}}
        <div class="flex flex-col gap-2 sm:flex-row">
            <button type="submit" name="action" value="preview" formtarget="_blank" class="btn-secondary w-full min-h-[44px] sm:w-auto">Preview IDP Form</button>
            <button type="submit" class="btn-primary w-full min-h-[44px] sm:w-auto">&darr; Generate IDP Form (PDF)</button>
        </div>
    </form>
</section>

<section class="grid grid-cols-1 gap-4 lg:grid-cols-3">
    <div class="card panel lg:col-span-2">
        <h2 class="panel-title">Generate a Report</h2>
        <form method="POST" action="{{ route('barangay.reports.generate') }}">
            @csrf
            <div class="field">
                <label for="rep-type">Report type</label>
                <select id="rep-type" name="report_type" required>
                    <option value="household_registry">Household Registry</option>
                    <option value="attendance">Attendance / Headcount</option>
                    <option value="relief">Relief Distribution</option>
                    <option value="relief_received">Relief Stock Received</option>
                    <option value="vulnerable">Vulnerable Population</option>
                    <option value="occupancy">Shelter Occupancy Summary</option>
                    {{-- Item 11b. Every member at this shelter, tagged or not.
                         Shelter Ranking is City Admin only -- ranking one
                         shelter is not a report. --}}
                    <option value="demographics">Evacuee Demographics</option>
                    {{-- Phase 11 - Shelter Demographic Summary --}}
                    <option value="shelter_demographic_summary">Shelter Demographic Summary</option>
                </select>
            </div>

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div class="field">
                    <label for="rep-from">Date from <small>(optional)</small></label>
                    <input type="date" id="rep-from" name="date_from" max="{{ now()->toDateString() }}">
                </div>
                <div class="field">
                    <label for="rep-to">Date to <small>(optional)</small></label>
                    <input type="date" id="rep-to" name="date_to" max="{{ now()->toDateString() }}">
                </div>
            </div>


            {{--
                PHASE 3 ITEM 11b -- the three demographic filters.

                They apply to EVERY report type, not just the member-level ones.
                All three are properties of a member, so on a household or
                shelter report they select which rows appear -- households or
                shelters containing at least one matching member -- rather than
                recomputing the figures inside those rows. The generated PDF says
                so in its header, and a Matching Members column is added so the
                distinction is visible in the table itself.

                Leaving all three on "Any" produces exactly the report you got
                before this feature existed.
            --}}
            <div class="field">
                <label>Demographic filters <small>(optional)</small></label>
                <p class="mt-1 mb-2 text-xs text-ink-muted">
                    Narrow the report to a sex, an age group, a vulnerable category, or
                    any combination. On household and shelter reports these choose which
                    rows appear; totals stay whole-household and whole-shelter figures,
                    and a Matching Members column is added.
                </p>
            </div>

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div class="field">
                    <label for="rep-sex">Sex</label>
                    <select id="rep-sex" name="sex">
                        <option value="">Any</option>
                        @foreach($filterOptions['sexes'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('sex') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label for="rep-age-tier">Age group</label>
                    <select id="rep-age-tier" name="age_tier">
                        <option value="">Any</option>
                        @foreach($filterOptions['tiers'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('age_tier') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="field">
                    <label for="rep-category">Vulnerable category</label>
                    <select id="rep-category" name="category">
                        <option value="">Any</option>
                        @foreach($filterOptions['categories'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('category') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="field">
                <label>File format</label>
                <div class="radio-list">
                    <label class="radio-row"><input type="radio" name="format" value="pdf" @checked(old('format', 'pdf') === 'pdf')> PDF (printable)</label>
                    <label class="radio-row"><input type="radio" name="format" value="xlsx" @checked(old('format') === 'xlsx')> Excel (.xlsx)</label>
                </div>
                <p class="mt-1 text-xs text-ink-muted">
                    Preview opens the PDF in a new tab and downloads nothing.
                    Excel files cannot be previewed and will always download.
                </p>
            </div>

            <div class="flex flex-col gap-2 sm:flex-row">
                <button type="submit" name="action" value="preview" formtarget="_blank" class="btn-secondary w-full min-h-[44px] sm:w-auto">Preview</button>
                <button type="submit" class="btn-primary w-full min-h-[44px] sm:w-auto">&darr; Generate &amp; Download</button>
            </div>
        </form>
    </div>

    <div>
        <h2 class="panel-title">Recently Generated</h2>
        <div class="card panel activity-panel">
            @forelse($recent as $r)
                {{-- Wraps instead of truncating below 640px: the type and the
                     format are both needed to tell two downloads apart. --}}
                <div class="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1 border-b border-surface-alt py-2 last:border-b-0">
                    <span>{{ $r->type_label }}
                        <small class="text-ink-muted">.{{ $r->format }}</small></span>
                    <time class="text-sm text-ink-muted">{{ $r->created_at->diffForHumans() }}</time>
                </div>
            @empty
                <p class="empty-note">Reports you generate will be listed here.</p>
            @endforelse
        </div>
    </div>
</section>
@endsection
