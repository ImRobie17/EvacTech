<?php

namespace App\Http\Controllers\CityAdmin;

use App\Http\Controllers\Controller;
use App\Models\Barangay;
use App\Models\EvacuationCenter;
use App\Models\Household;
use App\Models\VulnerableClassification;
use App\Services\AuditLogger;
use App\Services\HouseholdMemberSync;
use App\Support\AgeTier;
use App\Support\HouseholdCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EvacueeProfilingController extends Controller
{
    public function __construct(private HouseholdMemberSync $sync)
    {
    }

    public function index(Request $request)
    {
        // City-wide: every household in every shelter, filterable.
        $query = Household::with(['headMember', 'originBarangay', 'evacuationCenter', 'members.vulnerableClassifications']);

        if ($search = trim((string) $request->input('q'))) {
            $query->whereHas('members', fn ($q) => $q
                ->where('is_household_head', true)
                ->where('full_name', 'like', "%{$search}%"));
        }
        if ($barangay = $request->input('barangay')) {
            $query->where('origin_barangay_id', $barangay);
        }
        if ($shelter = $request->input('shelter')) {
            $query->where('evacuation_center_id', $shelter);
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }

        // Phase 2 item 6: separate age-group and category filters.
        if ($tier = $request->input('age_group')) {
            if (AgeTier::isValid($tier)) {
                $query->whereHas('members', fn ($q) => $q
                    ->whereRaw(AgeTier::sqlCase() . ' = ?', [$tier]));
            }
        }
        if ($vuln = $request->input('category')) {
            $query->whereHas('members.vulnerableClassifications', fn ($q) => $q
                ->where('vulnerable_classifications.id', $vuln));
        }

        // Single-headed households: derived from members_present == 1 on a
        // checked-in family, never a stored tag.
        if ($request->boolean('single_headed')) {
            $query->singleHeaded();
        }

        $households = $query->latest()->paginate(20)->withQueryString();
        $barangays = Barangay::orderBy('name')->get();
        $shelters = EvacuationCenter::orderBy('name')->get();
        $classifications = VulnerableClassification::selectable()->orderBy('name')->get();
        $ageGroups = AgeTier::options();

        return view('cityadmin.evacuees.index', compact(
            'households', 'barangays', 'shelters', 'classifications', 'ageGroups'
        ));
    }

    /** City Admin can register into ANY shelter (extra shelter-selector field). */
    public function store(Request $request)
    {
        $data = $request->validate([
            'origin_barangay_id' => ['required', 'exists:barangays,id'],
            'evacuation_center_id' => ['required', 'exists:evacuation_centers,id'],
            'address' => ['required', 'string', 'max:255'],
            'checkin' => ['nullable', 'boolean'],
            'members' => ['required', 'array', 'min:1'],
            'members.*.id' => ['nullable', 'integer'],
            // PHASE 3 ITEM 9. Blank on a non-head row is allowed:
            // HouseholdMemberSync fills it from the head's surname, which is
            // the common case and saves retyping it for every child during a
            // surge. The HEAD's surname stays required -- inheritance has to
            // come from somewhere, and an empty one would build every
            // full_name in the family as ", Juan".
            //
            // members.0 is the head on every form that posts here: the head row
            // is rendered at index 0 and carries the is_head hidden input.
            // HouseholdMemberSync resolves the head the same way and treats a
            // blank head surname as "do not inherit", so a future form that
            // flagged is_head elsewhere would degrade to a validation error
            // rather than to silently wrong names.
            'members.*.last_name' => ['nullable', 'string', 'max:100'],
            'members.0.last_name' => ['required', 'string', 'max:100'],
            'members.*.first_name' => ['required', 'string', 'max:100'],
            'members.*.middle_name' => ['nullable', 'string', 'max:100'],
            'members.*.birthdate' => ['nullable', 'date', 'before_or_equal:today'],
            'members.*.age_group' => [
                'required_without:members.*.birthdate',
                'nullable',
                'in:' . implode(',', array_keys(AgeTier::options())),
            ],
            'members.*.sex' => ['required', 'in:male,female'],
            'members.*.is_head' => ['nullable'],
            'members.*.is_present' => ['nullable'],
            'members.*.tags' => ['nullable', 'array'],
            'members.*.tags.*' => ['integer', 'exists:vulnerable_classifications,id'],
        ], [
            'members.*.age_group.required_without' => 'Choose an age group for any member without a date of birth.',
            'members.*.sex.required' => 'Sex is required for every member.',
        ]);

        $checkin = $request->boolean('checkin');
        $center = EvacuationCenter::findOrFail($data['evacuation_center_id']);

        $household = HouseholdCode::attempt(fn ($code) => DB::transaction(function () use ($code, $data, $checkin, $center) {
            $household = Household::create([
                'household_code' => $code,
                'origin_barangay_id' => $data['origin_barangay_id'],
                'origin_address' => $data['address'],
                'number_of_members' => count($data['members']),
                'status' => 'registered',
                'registered_by' => auth()->id(),
            ]);

            $this->sync->sync($household, $data['members'], checkin: $checkin);

            if ($checkin) {
                $present = $household->members()->where('is_present', true)->count();
                $household->update([
                    'evacuation_center_id' => $center->id,
                    'status' => 'checked_in',
                    'checked_in_at' => now(),
                    'checked_out_at' => null,
                    'members_present' => $present,
                ]);
                // Derived, not incremented -- and never flips the shelter to
                // 'full'/inactive: an overcapacity shelter stays active so it can
                // keep accepting and tracking evacuees.
                $center->recalcOccupancy();
            }

            return $household;
        }));

        AuditLogger::log('created', $household, "City Admin registered household {$household->household_code}");

        return redirect()->route('city.evacuees.index')
            ->with('success', "Household {$household->household_code} registered" . ($checkin ? ' and checked in.' : '.'));
    }
}
