<?php

namespace App\Http\Controllers\CityAdmin;

use App\Exports\ArrayExport;
use App\Http\Controllers\Concerns\FiltersReports;
use App\Http\Controllers\Concerns\RendersIdpForm;
use App\Models\EvacuationCenter;
use App\Models\GeneratedReport;
use App\Models\Household;
use App\Models\HouseholdMember;
use App\Models\ReliefTransaction;
use App\Services\AuditLogger;
use App\Support\IdpForm;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends \App\Http\Controllers\Controller
{
    use FiltersReports;
    use RendersIdpForm;

    /**
     * PHASE 3 ITEM 11b added the last two.
     *
     * 'demographics' is every member in scope, not only the tagged ones, so the
     * three demographic filters have something to filter that is not already
     * restricted to vulnerable people.
     *
     * 'shelter_ranking' is City Admin only and deliberately absent from the
     * barangay list: barangay staff operate one shelter at a time, and a
     * ranking of one row is not a report.
     *
     * PHASE 11 added 'shelter_demographic_summary' -- aggregated counts by
     * vulnerability category for a specific shelter, as requested by professor.
     */
    public const TYPES = [
        'household_registry', 'attendance', 'relief', 'vulnerable',
        'occupancy', 'demographics', 'shelter_ranking', 'shelter_demographic_summary',
        'relief_received',
    ];

    public function index()
    {
        $shelters = EvacuationCenter::orderBy('name')->get();
        $recent = GeneratedReport::with('generatedBy')
            ->where('generated_by', auth()->id())
            ->latest()->take(8)->get();

        // Pre-fill for the IDP panel's two "Number of Affected ..." inputs.
        // City-wide, matching that panel's default "All shelters (accumulated)"
        // selection. Labelled in the view as a live headcount, because it is not
        // the city-wide disaster figure the official field means.
        $idpCounts = IdpForm::headcount();

        // Item 11b. Prepared here rather than read from the class in Blade --
        // controllers prepare, views render.
        $filterOptions = $this->reportFilterOptions();

        return view('cityadmin.reports.index', compact('shelters', 'recent', 'idpCounts', 'filterOptions'));
    }

    /**
     * The CSWDO IDP Monitoring Form (Phase 3 item 11a).
     *
     * A SEPARATE action, deliberately not another entry in self::TYPES. TYPES is
     * the whitelist for the generic dropdown, which also offers an xlsx radio
     * and routes into buildDataset(); this form is a fixed two-cross-tab layout,
     * so an xlsx of it would be a broken artifact. PDF only, its own route, its
     * own view, and the working report types are left untouched.
     *
     * SCOPE. A shelter id prints that one centre, which is how CSWDO fills the
     * sheet in by hand. Leaving it blank prints every shelter accumulated, with
     * the header reading "Accumulated Shelters" -- a city-level roll-up the
     * paper form has no equivalent of, and the reason the barangay side has no
     * such option.
     */
    public function idp(Request $request)
    {
        $data = $request->validate([
            // DROP D. Preview is a second SUBMIT BUTTON, not a third format.
            // Nothing else may be posted here, so the whitelist is one value.
            'action' => ['nullable', 'in:preview'],
            'center' => ['nullable', 'exists:evacuation_centers,id'],
            'disaster_name' => ['required', 'string', 'max:150'],
            'disaster_date' => ['required', 'date', 'before_or_equal:today'],
            'affected_families' => ['nullable', 'integer', 'min:0', 'max:9999999'],
            'affected_persons' => ['nullable', 'integer', 'min:0', 'max:9999999'],
        ], [
            'disaster_name.required' => 'Enter the name of the disaster, e.g. Typhoon Kristine.',
            'disaster_date.required' => 'Enter the date the disaster occurred.',
        ]);

        $preview = ($data['action'] ?? null) === 'preview';

        // Empty center = accumulate every shelter. The barangay relation is
        // eager-loaded because the header block prints the shelter's barangay.
        $center = ! empty($data['center'])
            ? EvacuationCenter::with('barangay')->find($data['center'])
            : null;

        $form = $center ? IdpForm::forCenter($center) : IdpForm::accumulated();

        // DROP D. A preview IS logged. It renders a full city-wide roll-up,
        // and a read that leaves no trace is worse than a Recently Generated
        // list that fills up faster. The format stays 'pdf' -- that column
        // records the artifact, not how it was delivered -- and the audit
        // description is the only thing that distinguishes the two.
        $record = GeneratedReport::create([
            'report_type' => IdpForm::TYPE,
            'format' => 'pdf',
            'generated_by' => auth()->id(),
            'evacuation_center_id' => $center?->id,
        ]);

        $scope = $center ? $center->name : IdpForm::ACCUMULATED_LABEL;
        $verb = $preview ? 'Previewed' : 'Generated';
        AuditLogger::log('created', $record,
            "{$verb} IDP Monitoring Form for {$scope} (disaster: {$data['disaster_name']})");

        return $this->renderIdpPdf($data, $form, $preview);
    }

    public function generate(Request $request)
    {
        $data = $request->validate(array_merge([
            'report_type' => ['required', 'in:' . implode(',', self::TYPES)],
            'format' => ['required', 'in:pdf,xlsx'],
            // DROP D. Deliberately NOT a third value on the format radio.
            // Preview is orthogonal to format: a 'preview' radio would create
            // the combination preview+xlsx, which is invalid and would need
            // guarding anyway, and it would write the string 'preview' into
            // generated_reports.format where a real format belongs. A separate
            // submit button leaves format clean.
            'action' => ['nullable', 'in:preview'],
            'center' => ['nullable', 'exists:evacuation_centers,id'],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
        ], $this->reportFilterRules()));

        $preview = ($data['action'] ?? null) === 'preview';

        // A spreadsheet cannot be rendered inline by a browser. Refuse the
        // combination out loud instead of quietly downloading -- a control that
        // silently does something other than what it says is the thing this
        // drop exists to avoid. withInput() keeps the operator's shelter,
        // filters and dates so they only have to change the one radio.
        if ($preview && $data['format'] === 'xlsx') {
            return back()->withInput()->withErrors([
                'format' => 'Excel files cannot be previewed. Choose PDF to preview, or press Generate to download the spreadsheet.',
            ]);
        }

        // null center = city-wide (all shelters)
        $center = ! empty($data['center']) ? EvacuationCenter::find($data['center']) : null;

        $filters = $this->reportFilters($data);

        [$headings, $rows, $title] = $this->buildDataset(
            $data['report_type'], $data['date_from'] ?? null, $data['date_to'] ?? null, $center, $filters
        );

        $record = GeneratedReport::create([
            'report_type' => $data['report_type'],
            'format' => $data['format'],
            'date_from' => $data['date_from'] ?? null,
            'date_to' => $data['date_to'] ?? null,
            'generated_by' => auth()->id(),
            'evacuation_center_id' => $center?->id,
        ]);

        $scope = $center ? $center->name : 'City-wide';
        $filterLabels = $this->reportFilterLabels($filters);

        // The filters are NOT persisted on generated_reports -- that would be a
        // migration for a column nothing reads back. They are recorded here,
        // where an auditor can already see who generated what and when.
        $note = $filterLabels === [] ? '' : ('; filters: ' . implode(' | ', $filterLabels));
        $verb = $preview ? 'Previewed' : 'Generated';
        AuditLogger::log('created', $record, "{$verb} {$title} report ({$scope}, {$data['format']}{$note})");

        $filename = str_replace(' ', '_', strtolower($title))
            . $this->reportFilterSlug($filters)
            . '_' . now()->format('Ymd_His');

        if ($data['format'] === 'xlsx') {
            return Excel::download(new ArrayExport($headings, $rows), $filename . '.xlsx');
        }

        $pdf = Pdf::loadView('reports.pdf.generic', [
            'title' => $title,
            'center' => $center,
            'scopeLabel' => $scope,
            'headings' => $headings,
            'rows' => $rows,
            'from' => $data['date_from'] ?? null,
            'to' => $data['date_to'] ?? null,
            'filters' => $filterLabels,
            'filterNote' => $this->reportFilterNote($data['report_type'], $filters),
            'generatedBy' => auth()->user()->name,
        ])->setPaper('a4', 'landscape');

        return $this->pdfResponse($pdf, $filename . '.pdf', $preview);
    }

    /**
     * Same datasets as the barangay report, but $center may be null to mean
     * "all shelters city-wide". When null, center-scoped queries drop that
     * where-clause.
     *
     * $filters is [] for an unfiltered report, in which case every query and
     * every heading row below behaves exactly as it did before item 11b.
     *
     * @return array{0: string[], 1: array[], 2: string}
     */
    private function buildDataset(
        string $type,
        ?string $from,
        ?string $to,
        ?EvacuationCenter $center,
        array $filters = []
    ): array {
        $range = fn ($q, $col = 'created_at') => $q
            ->when($from, fn ($q) => $q->whereDate($col, '>=', $from))
            ->when($to, fn ($q) => $q->whereDate($col, '<=', $to));

        $centerFilter = fn ($q, $col = 'evacuation_center_id') => $q->when($center, fn ($q) => $q->where($col, $center->id));

        return match ($type) {
            'household_registry' => [
                $this->withMatchColumn(
                    ['Household ID', 'Household Head', 'Family Size', 'Barangay', 'Address', 'Status', 'Shelter', 'Registered On'],
                    $filters, 'Matching Members'
                ),
                $range($this->filterHouseholds(
                    Household::with(['headMember', 'originBarangay', 'evacuationCenter'])
                        ->when($center, fn ($q) => $q->where('evacuation_center_id', $center->id)),
                    $filters
                ))->get()->map(fn ($h) => $this->withMatchColumn([
                    $h->household_code, $h->headMember?->full_name ?? '-', $h->number_of_members,
                    $h->originBarangay?->name, $h->origin_address,
                    ucfirst(str_replace('_', ' ', $h->status)), $h->evacuationCenter?->name ?? '-',
                    $h->created_at->format('M d, Y'),
                ], $filters, $h))->all(),
                'Household Registry',
            ],
            'attendance' => [
                $this->withMatchColumn(
                    ['Household ID', 'Household Head', 'Shelter', 'Members Present', 'Status', 'Checked In', 'Checked Out'],
                    $filters, 'Matching Members'
                ),
                $centerFilter($range($this->filterHouseholds(
                    Household::with(['headMember', 'evacuationCenter'])->whereNotNull('checked_in_at'),
                    $filters
                ), 'checked_in_at'))
                    ->get()->map(fn ($h) => $this->withMatchColumn([
                        $h->household_code, $h->headMember?->full_name ?? '-', $h->evacuationCenter?->name ?? '-',
                        $h->members_present, ucfirst(str_replace('_', ' ', $h->status)),
                        $h->checked_in_at?->format('M d, Y h:i A'), $h->checked_out_at?->format('M d, Y h:i A') ?? '-',
                    ], $filters, $h))->all(),
                'Attendance Headcount',
            ],
            'relief' => [
                ['Date', 'Shelter', 'Household Head', 'Relief Good', 'Quantity', 'Distributed By'],
                $centerFilter($range($this->filterRelief(
                    ReliefTransaction::with(['household.headMember', 'evacuationCenter', 'reliefGood', 'recordedBy'])
                        ->where('type', 'distributed'),
                    $filters
                ), 'transaction_date'))
                    ->latest('transaction_date')->get()->map(fn ($t) => [
                        $t->transaction_date->format('M d, Y'), $t->evacuationCenter?->name ?? '-',
                        $t->household?->headMember?->full_name ?? '-', $t->reliefGood->name,
                        $t->quantity . ' ' . $t->reliefGood->unit, $t->recordedBy?->name ?? '-',
                    ])->all(),
                'Relief Distribution',
            ],

            /* DROP B2 -- stock RECEIVED, the counterpart to the distribution
               report above.

               THE TRAP, AND IT IS THE SAME ONE DROP 0 FIXED. The three
               demographic filters apply to EVERY type on this form (gotcha 39).
               A received transaction has household_id = NULL, so running this
               arm through filterRelief() -- which does
               whereHas('household.members', ...) -- would return ZERO ROWS the
               moment any filter is set, silently, while the PDF header
               cheerfully printed "Filtered by: Category: PWD". A report that
               quietly answers a different question from the one printed on it is
               worse than one that crashes.

               So the demographic filters are NOT applied here at all, and
               FiltersReports::reportFilterNote() carries a case saying so in
               plain words. The date range still applies: that is a property of
               the receipt, not of a household.

               allocated_in rows are INCLUDED by decision. Stock from an approved
               city restock is real stock-in, and since Drop B1 it can carry a
               donor too, because a donation does not always reach a shelter
               directly. Excluding them would make this report disagree with the
               inventory it exists to explain. */
            'relief_received' => [
                ['Date', 'Shelter', 'Barangay', 'Item', 'Quantity', 'Donor Type', 'Donor Name', 'Value (PHP)', 'Received By', 'Remarks'],
                $this->reliefReceivedRows(
                    $centerFilter($range(
                        ReliefTransaction::with(['reliefGood', 'recordedBy', 'evacuationCenter.barangay'])
                            ->whereIn('type', ReliefTransaction::STOCK_IN_TYPES),
                        'transaction_date'
                    ))->latest('transaction_date')->get(),
                    true
                ),
                'Relief Stock Received',
            ],

            // ITEM 11b FIX. This used to select on whereHas('vulnerabilities')
            // and print vulnerableClassifications->pluck('name'), so a member
            // whose only tag was a RETIRED category still appeared, and retired
            // labels printed beside live ones. activeClassifications is the
            // relation HouseholdMember provides for exactly this, and the whole
            // codebase keys on code rather than name.
            //
            // The Age column also used to print $m->age alone, which is null for
            // anyone registered by age group with no birthdate -- a blank cell in
            // a signed report. The derived tier is authoritative and always
            // present, so it gets its own column and the numeric age falls back
            // to a dash.
            // DROP D added Household Head, Contact Number and Head Contact.
            // This report is already ONE ROW PER PERSON; the gap was never
            // person-vs-household, it was that the person rows do not say who
            // to call. Two separate number columns rather than one with a
            // fallback: the heading then says whose number it is, and a blank
            // Contact Number beside a populated Head Contact reads correctly
            // without a marker. contact_number lives on household_members, so
            // the head's is one eager-load away via household.headMember.
            //
            // headMember(), NOT currentHead(). The acting head is a shelter
            // operations stand-in and v10 keeps it out of reports entirely.
            //
            // ELEVEN COLUMNS on landscape A4. The widest report in the system.
            // If it crowds, the Household Head NAME is the column to drop --
            // the household code already identifies the family and the two
            // numbers are the point of the change.
            'vulnerable' => [
                ['Name', 'Age', 'Age Group', 'Sex', 'Household', 'Shelter', 'Categories',
                    'Household Head', 'Contact Number', 'Head Contact', 'Present'],
                $range($this->filterMembers(
                    HouseholdMember::with(['household.evacuationCenter', 'household.headMember', 'activeClassifications'])
                        ->whereHas('activeClassifications')
                        ->when($center, fn ($q) => $q->whereHas('household', fn ($q) => $q->where('evacuation_center_id', $center->id))),
                    $filters
                ), 'household_members.created_at')->get()->map(fn ($m) => [
                    $m->full_name, $m->age ?? '-', $m->ageTierLabel(), ucfirst((string) $m->sex),
                    $m->household?->household_code ?? '-', $m->household?->evacuationCenter?->name ?? '-',
                    $m->activeClassifications->pluck('name')->implode(', '),
                    $m->household?->headMember?->full_name ?? '-',
                    $m->contact_number ?: '-',
                    $m->household?->headMember?->contact_number ?: '-',
                    $m->is_present ? 'Yes' : 'No',
                ])->all(),
                'Vulnerable Population',
            ],

            // ITEM 11b. Every member in scope, tagged or not. Vulnerable
            // Population answers "who needs special handling"; this answers
            // "who is here", which is the question the three filters are for.
            'demographics' => [
                // DROP D. Same three columns as 'vulnerable', in the same
                // order. The two reports are read side by side and a column
                // that moves between them is a column that gets misread.
                ['Name', 'Age', 'Age Group', 'Sex', 'Household', 'Shelter', 'Categories',
                    'Household Head', 'Contact Number', 'Head Contact', 'Present'],
                $range($this->filterMembers(
                    HouseholdMember::with(['household.evacuationCenter', 'household.headMember', 'activeClassifications'])
                        ->when($center, fn ($q) => $q->whereHas('household', fn ($q) => $q->where('evacuation_center_id', $center->id))),
                    $filters
                ), 'household_members.created_at')->get()->map(fn ($m) => [
                    $m->full_name, $m->age ?? '-', $m->ageTierLabel(), ucfirst((string) $m->sex),
                    $m->household?->household_code ?? '-', $m->household?->evacuationCenter?->name ?? '-',
                    $m->activeClassifications->pluck('name')->implode(', ') ?: '-',
                    $m->household?->headMember?->full_name ?? '-',
                    $m->contact_number ?: '-',
                    $m->household?->headMember?->contact_number ?: '-',
                    $m->is_present ? 'Yes' : 'No',
                ])->all(),
                'Evacuee Demographics',
            ],

            // Occupancy is a live snapshot, so the date range does not apply to
            // this report or to the ranking below -- it never did.
            'occupancy' => [
                $this->withMatchColumn(
                    ['Shelter', 'Barangay', 'Capacity', 'Occupancy', 'Occupancy %', 'Households', 'Status'],
                    $filters, 'Matching Members'
                ),
                $this->filterShelters(
                    EvacuationCenter::with('barangay')->when($center, fn ($q) => $q->whereKey($center->id)),
                    $filters
                )->get()->map(fn ($c) => $this->withMatchColumn([
                    $c->name, $c->barangay?->name, $c->capacity, $c->current_occupancy,
                    ($c->capacity > 0 ? round($c->current_occupancy / $c->capacity * 100) : 0) . '%',
                    Household::where('evacuation_center_id', $c->id)->where('status', 'checked_in')->count(),
                    $c->statusLabel(),
                ], $filters, $c))->all(),
                'Shelter Occupancy Summary',
            ],

            // ITEM 11b -- the roadmap's "top shelters / most-least data".
            //
            // Sorted in PHP rather than SQL: occupancy % is capacity-relative and
            // capacity can be zero, so ordering it in the database would mean a
            // division guard in raw SQL for the sake of ranking a few dozen rows.
            'shelter_ranking' => [
                $this->withMatchColumn(
                    ['Rank', 'Shelter', 'Barangay', 'Capacity', 'Occupancy', 'Occupancy %', 'Households', 'Status'],
                    $filters, 'Matching Members'
                ),
                $this->filterShelters(
                    EvacuationCenter::with('barangay')->when($center, fn ($q) => $q->whereKey($center->id)),
                    $filters
                )->get()
                    ->map(fn ($c) => [
                        'center' => $c,
                        'percent' => $c->capacity > 0 ? $c->current_occupancy / $c->capacity * 100 : 0.0,
                    ])
                    ->sortByDesc('percent')
                    ->values()
                    ->map(fn ($entry, $i) => $this->withMatchColumn([
                        $i + 1,
                        $entry['center']->name,
                        $entry['center']->barangay?->name ?? '-',
                        $entry['center']->capacity,
                        $entry['center']->current_occupancy,
                        round($entry['percent']) . '%',
                        Household::where('evacuation_center_id', $entry['center']->id)->where('status', 'checked_in')->count(),
                        $entry['center']->statusLabel(),
                    ], $filters, $entry['center']))
                    ->all(),
                'Shelter Ranking',
            ],

            // PHASE 11 - Shelter Demographic Summary Report
            // Aggregated counts by vulnerability category for a specific shelter
            // as requested by professor to see demographic breakdown per shelter
            'shelter_demographic_summary' => [
                ['Shelter', 'Barangay', 'Vulnerability Category', 'Count', 'Percentage', 'Currently Present'],
                $this->filterShelters(
                    EvacuationCenter::with('barangay')->when($center, fn ($q) => $q->whereKey($center->id)),
                    $filters
                )->get()
                    ->map(function ($c) use ($filters) {
                        // FIX. As shipped, this closure built $memberQuery,
                        // applied the filters to it, and then never executed it.
                        // Every branch below reads $members and $totalMembers,
                        // neither of which was ever assigned, so the report
                        // fataled with "Call to a member function filter() on
                        // null" on every single run. The query is now run.
                        //
                        // SECOND FIX, QUIETER AND WORSE. This copy never applied
                        // the age_tier filter at all -- the barangay copy had the
                        // block, this one did not. Once the fatal was gone, a
                        // City Admin picking an age tier would have got an
                        // unfiltered population under a PDF banner reading
                        // "Filtered by: Age group: Senior Citizen". A report that
                        // crashes gets fixed; a report that quietly answers a
                        // different question than the one printed on it gets
                        // signed. Both copies now go through the same primitive,
                        // so they cannot diverge again.
                        //
                        // THE FILTER SUBSET IS DELIBERATE. sex and age_tier
                        // decide WHO IS COUNTED. category decides WHICH ROW IS
                        // PRINTED, further down. Passing category in here as
                        // well would narrow the population to that one category
                        // and every percentage would come out as 100%.
                        $members = $this->filterMembers(
                            HouseholdMember::with(['activeClassifications'])
                                ->whereHas('household', fn ($q) => $q->where('evacuation_center_id', $c->id)),
                            array_intersect_key($filters, array_flip(['sex', 'age_tier']))
                        )->get();

                        $totalMembers = $members->count();

                        // Fetched once. The else branch below re-fetched an
                        // identical collection into this same variable.
                        $classifications = \App\Models\VulnerableClassification::where('is_selectable', true)
                            ->orderBy('name')
                            ->get();

                        $summaryRows = [];

                        // If category filter is set, only show that specific category
                        if (! empty($filters['category'])) {
                            $classification = \App\Models\VulnerableClassification::where('code', $filters['category'])
                                ->where('is_selectable', true)
                                ->first();

                            if ($classification) {
                                $count = $members->filter(function ($member) use ($classification) {
                                    return $member->activeClassifications->contains('id', $classification->id);
                                })->count();

                                $presentCount = $members->filter(function ($member) use ($classification) {
                                    return $member->activeClassifications->contains('id', $classification->id) && $member->is_present;
                                })->count();

                                $percentage = $totalMembers > 0 ? round(($count / $totalMembers) * 100, 1) : 0;

                                $summaryRows[] = [
                                    $c->name,
                                    $c->barangay?->name ?? '-',
                                    $classification->name,
                                    $count,
                                    $percentage . '%',
                                    $presentCount,
                                ];
                            }
                        } else {
                            // No category filter: every classification gets a row.
                            foreach ($classifications as $classification) {
                                $count = $members->filter(function ($member) use ($classification) {
                                    return $member->activeClassifications->contains('id', $classification->id);
                                })->count();

                                $presentCount = $members->filter(function ($member) use ($classification) {
                                    return $member->activeClassifications->contains('id', $classification->id) && $member->is_present;
                                })->count();

                                $percentage = $totalMembers > 0 ? round(($count / $totalMembers) * 100, 1) : 0;

                                $summaryRows[] = [
                                    $c->name,
                                    $c->barangay?->name ?? '-',
                                    $classification->name,
                                    $count,
                                    $percentage . '%',
                                    $presentCount,
                                ];
                            }

                            // Add row for members with no vulnerabilities (only when no category filter)
                            $noVulnerabilityCount = $members->filter(function ($member) {
                                return $member->activeClassifications->isEmpty();
                            })->count();

                            $noVulnerabilityPresent = $members->filter(function ($member) {
                                return $member->activeClassifications->isEmpty() && $member->is_present;
                            })->count();

                            $noVulnerabilityPercentage = $totalMembers > 0 ? round(($noVulnerabilityCount / $totalMembers) * 100, 1) : 0;

                            $summaryRows[] = [
                                $c->name,
                                $c->barangay?->name ?? '-',
                                'No Vulnerability',
                                $noVulnerabilityCount,
                                $noVulnerabilityPercentage . '%',
                                $noVulnerabilityPresent,
                            ];
                        }

                        // Add total row
                        $totalPresent = $members->where('is_present', true)->count();
                        $summaryRows[] = [
                            $c->name,
                            $c->barangay?->name ?? '-',
                            'TOTAL',
                            $totalMembers,
                            '100%',
                            $totalPresent,
                        ];

                        return $summaryRows;
                    })->flatten(1)->all(),
                'Shelter Demographic Summary',
            ],
        };
    }
}
